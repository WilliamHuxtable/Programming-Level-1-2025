//
//  FitForgeApp.swift
//  FitForge
//
//  Created by William Huxtable - 811 on 2025-05-05.
//

import SwiftUI

@main
struct FitForgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
