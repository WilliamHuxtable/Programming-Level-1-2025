import SwiftUI

struct UsersView: View {
    @State private var usernames: Set<String> = [
        "BenchGuy",
        "BenchHater",
        "DipGuy",
        "PullUpGuy",
        "SquatGuy",
        "BBRowGuy",
        "CurlGuy",
        "MPGuy",
        "DeadliftHater",
        "SquatHater",
        "MPHater",
        "BBRowHater",
        "PullupHater",
        "DipsHater",
        "CurlHater"
    ]
    @State private var searchUsernames = ""
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("MainBackgroundColor")
                    .ignoresSafeArea()
                List {
                    ForEach(searchResults.sorted(), id: \.self) { name in
                        NavigationLink(destination: UserSearchView(username: name)) {
                            HStack {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .foregroundStyle(Color("MainTextColor"))
                                    .scaledToFit()
                                    .frame(width:50,height:50)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    .overlay{
                                        Circle().stroke(Color("BorderColor"), lineWidth: 4)
                                    }
                                    .padding(.trailing, 20)
                                Text(name)
                                    .foregroundStyle(Color("MainTextColor"))
                            }
                            }
                            .listRowBackground(Color("SubBackgroundColor"))
                    }
                }
                .padding([.leading, .trailing], 4)
                .searchable(text: $searchUsernames)
                .scrollContentBackground(.hidden)            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Users")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundStyle(Color("MainTextColor"))
            }
        }
    }
    
    var searchResults: [String] {
        if searchUsernames.isEmpty {
            return usernames.sorted()
        } else {
            return usernames.filter { $0.localizedCaseInsensitiveContains(searchUsernames) }
                                            .sorted()
        }
    }
}


struct UserSearchView: View {
    let username: String
    
    var body: some View {
        ZStack {
            Color("MainBackgroundColor")
                .ignoresSafeArea()
            VStack(alignment: .leading) {
                HStack {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .foregroundStyle(Color("MainTextColor"))
                        .scaledToFit()
                        .frame(width:100,height:130)
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .overlay{
                            Circle().stroke(Color("BorderColor"), lineWidth: 4)
                        }
                        .padding()
                    VStack {
                        HStack {
                            Text("\(username)")
                                .font(.title2)
                                .foregroundStyle(Color("MainTextColor"))
                                .background(Color("SubBackgroundColor"))
                                .padding([.top, .bottom, .leading, .trailing], 4)
                                .multilineTextAlignment(.center)
                        }
                        HStack {
                            Text("10")
                                .foregroundStyle(Color("MainTextColor"))
                                .fontWeight(.bold)
                            Text("Friends")
                                .foregroundStyle(Color("MainTextColor"))
                        }
                        .padding(.trailing)
                    }
                    
                }
                .frame(height: 130)
                .padding([.top, .bottom, .leading, .trailing])
                .background(Color("SubBackgroundColor"))
                .overlay(
                    Rectangle()
                        .frame(height: 3)
                        .foregroundColor(Color("BorderColor")),
                    alignment: .bottom
                )
                Spacer()
                Text("ABOUT")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .font(.system(size: 17))
                    .foregroundStyle(Color("MainTextColor"))
                    .padding([.leading, .trailing])
                    .padding([.leading, .trailing])
                    .padding(.bottom, 4)
                Text("Lorem ipsum.")
                    .foregroundStyle(Color("MainTextColor"))
                    .padding([.top, .bottom, .leading, .trailing], 4)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color("SubBackgroundColor"))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color("BorderColor"), lineWidth: 2)
                    )
                    .padding([.leading, .trailing])
                    .padding([.leading, .trailing])
                
                HStack {
                    Text("STATS")
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .font(.system(size: 17))
                        .foregroundStyle(Color("MainTextColor"))
                        .padding([.leading, .trailing])
                        .padding(.bottom, 4)
                    
                }
                .padding(.trailing)
                .fontWeight(.semibold)
                .foregroundStyle(Color("MainTextColor"))
                .toggleStyle(SwitchToggleStyle(tint: Color("SubTextColor")))
                
                HStack {
                    Spacer()
                    Text("Lift (lbs)")
                        .foregroundStyle(Color("MainTextColor"))
                        .padding(8)
                    Spacer()
                    Text("Weight (lbs)")
                        .foregroundStyle(Color("MainTextColor"))
                    Spacer()
                    Text("BW Ratio")
                        .foregroundStyle(Color("MainTextColor"))
                    Spacer()
                }
            }
            }
        }
        }

#Preview {
    UsersView()
}
