//
//  GlobalView.swift
//  FitForge
//
//  Created by William Huxtable - 811 on 2025-06-02.
//

import SwiftUI

struct GlobalView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    GlobalView()
}
