//
//  foundation.swift
//  FitForge
//
//  Created by William Huxtable - 811 on 2025-05-21.
//

import Foundation

struct DataPoint: Identifiable {
    let id = UUID()
    var value: Double
}
