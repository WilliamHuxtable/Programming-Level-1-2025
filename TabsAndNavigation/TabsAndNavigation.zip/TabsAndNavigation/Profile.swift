//
//  Profile.swift
//  TabsAndNavigation
//
//  Created by William Huxtable - 811 on 2025-04-08.
//

import Foundation

struct Profile{
    private var username: String = "Name"
}
