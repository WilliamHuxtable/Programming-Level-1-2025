//
//  TabsAndNavigationApp.swift
//  TabsAndNavigation
//
//  Created by William Huxtable - 811 on 2025-04-07.
//

import SwiftUI

@main
struct TabsAndNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
